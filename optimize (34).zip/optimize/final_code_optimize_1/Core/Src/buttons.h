#include <stm32f042x6.h>
#include "main.h"

#include "math.h"
#include "string.h"
#include "fonts.h"
#include "ssd1306.h"


#include "counters.h"
int TT=0;
int kl=0;
int flag_button=0;
volatile int btt=0;

int butt_flag=0;

volatile unsigned long button_previousMillis = 0;        
const long button_interval = 10; 

volatile unsigned long display_previousMillis = 0;        
const long display_interval = 50; 


void butt_config(void){

//ENABLE PORTA CLK
RCC->AHBENR |=(1<<17);
	
	
	//INPUT MODE
	GPIOA->MODER &=~(1<<2);
	GPIOA->MODER &=~(1<<3);
	
	
	GPIOA->OSPEEDR |=(1<<2);
	GPIOA->OSPEEDR |=(1<<3);
	
	//PULL DOWN
	GPIOA->PUPDR |=(1<<3);
	GPIOA->PUPDR &=(1<<2);
	
	GPIOA->BSRR |=(1<<1);
	
	EXTI->IMR |=(1<<1);
	EXTI->EMR |=(1<<1);
	//rising edge
	EXTI->RTSR |=(1U<<1);
	
	//falling edge disable
	//EXTI->FTSR &=~(1U<<1);
	
	NVIC_EnableIRQ(EXTI0_1_IRQn);
	NVIC_SetPriority(EXTI0_1_IRQn,1); 

}
void EXTI0_1_IRQHandler(void){
	
	


 
	EXTI->PR |= (1U<<1);	
		
	

}


 int button_prees(void){
 
	 int button_pressed=0;
 
 if(GPIOA->IDR &(1<<1)){
	 //butt_flag
 volatile unsigned long display_currentMillis = counter;
	 if(display_currentMillis-display_previousMillis>=display_interval){
	 
		 display_previousMillis=display_currentMillis;
		 button_pressed=1;
		 HAL_Delay(130);
    //flag_button=0;
	 //btt++;
		 
		 //if(btt==2){
		
	     // btt=0;
       //button_pressed=1;
			 
		
			 
		 }
		 
		 
			
	 }
 
	 else{
		 
		 
		 button_pressed=0;
		 
		 }
 
 
 
 
 return button_pressed;
 
 }



