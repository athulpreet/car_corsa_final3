
#include <stm32f042x6.h>
#include "main.h"


volatile unsigned long counter=0;

volatile unsigned long previousMillis = 0;        
const long interval = 1000; 





















void counter_timer_config(void){

	
	/*TIMER 2 IS 32BIT
	*/
	
//TIMER 2 CLK ENABLE
RCC->APB1ENR |=(1<<0);
	
	
	TIM2->PSC =8;
	TIM2->ARR=1000;
	
//Only counter overflow/underflow generates an update interrupt 
	TIM2->CR1 |=(1<<2);
	
	
	//UPDATE INTURRPT ENABLE
	TIM2->DIER |=(1<<0);
	
	
	//UPDATE GENERATION 
	TIM2->EGR |=(1<<0);
	
	
	//ENABLE THE COUNTER
	TIM2->CR1 |=(1<<0);
	
	
	NVIC_EnableIRQ(TIM2_IRQn);
	NVIC_SetPriority(TIM2_IRQn,2);
	

}

void TIM2_IRQHandler(void){

	counter++;
TIM2->SR &=~(1<<0);
}

